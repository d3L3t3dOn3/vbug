### Description
(ID) Tool ini berfungsi untuk membuat virus secara instan. Dengan begitu pengguna VBug Maker dapat menggunakannya dengan mudah dan cepat. Di dalam software tersebut telah disediakan 3 fitur yang bisa kita pilih, Anvima ( Virus Untuk Android ), Winvima ( Virus untuk Android ) & MACvima ( Virus untuk MACOSX )
(EN) This tool works to create viruses instantly. That way VBug Maker users can use it easily and quickly. Inside the software has provided 3 features that we can choose, Anvima (Virus For Android), Winvima (Virus for Window) & MACvima (Virus for MACOSX)

### Requirements
• Python 2.7.x
• OS (Android, Linux)

### Run Crotz
cd vbug
python vbug.py

### Social Media
My Facebook ~> https://www.fb.com/100004136748473
My Github   ~> https://github.com/Gameye98

### Team or Group
AndroSec1337 Cyber Team        ~> https://mbasic.facebook.com/groups/260954221031092
Blackhole Programming Security ~> https://mbasic.facebook.com/groups/1704985559810669

### Thanks
to Mr_Silent ( For the Android Virus )
to Ghifari Rudian ( For the idea )
to Mr_/bon'007
to Mr.b0t4k
to Mr.Holmes
to ./BlackFire
to ID_OUT96
to ./Xi4u7
to Imam Basyari
to 7grok
to M2807
to Mr.RM

(ID) Maafkan saya bila program ini tidak sesuai dengan ekspetasi anda, saya adalah seorang newbie coder jadi tolong dimengerti.
(EN) Forgive me if this program does not match with your expectations, I am a newbie coder so please understand.